package com.qclient;

import java.util.Locale;

/** One adjustable option of a module. */
public abstract class Setting {
    public final String key;
    public final String label;

    protected Setting(String key, String label) {
        this.key = key;
        this.label = label;
    }

    public abstract String display();
    public abstract void next();      // "+" button / toggle
    public abstract void previous();  // "-" button
    public abstract String save();
    public abstract void load(String value);

    public static final class Num extends Setting {
        public double value;
        private final double min, max, step;

        public Num(String key, String label, double def, double min, double max, double step) {
            super(key, label);
            this.value = def;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public float f() { return (float) value; }

        private void set(double v) {
            v = Math.max(min, Math.min(max, v));
            value = Math.round(v / step) * step;
        }

        @Override public String display() { return label + ": " + String.format(Locale.ROOT, "%.2f", value).replaceAll("0+$", "").replaceAll("\\.$", ""); }
        @Override public void next() { set(value + step); }
        @Override public void previous() { set(value - step); }
        @Override public String save() { return Double.toString(value); }
        @Override public void load(String v) {
            try { set(Double.parseDouble(v)); } catch (NumberFormatException ignored) { }
        }
    }

    public static final class Bool extends Setting {
        public boolean value;

        public Bool(String key, String label, boolean def) {
            super(key, label);
            this.value = def;
        }

        @Override public String display() { return label + ": " + (value ? "да" : "нет"); }
        @Override public void next() { value = !value; }
        @Override public void previous() { value = !value; }
        @Override public String save() { return Boolean.toString(value); }
        @Override public void load(String v) { value = Boolean.parseBoolean(v); }
    }
}
