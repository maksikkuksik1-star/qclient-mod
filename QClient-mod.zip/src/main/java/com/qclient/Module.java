package com.qclient;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String description;
    public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean on, Minecraft mc) {
        if (on == enabled) return;
        enabled = on;
        if (!on) onDisable(mc);
    }

    public void toggle(Minecraft mc) { setEnabled(!enabled, mc); }

    /** Called every client tick while enabled and a world is loaded. */
    public abstract void tick(Minecraft mc);

    protected void onDisable(Minecraft mc) { }
}
