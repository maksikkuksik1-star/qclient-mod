package com.qclient;

import com.qclient.modules.Aimbot;
import com.qclient.modules.Fullbright;
import com.qclient.modules.KillAura;
import com.qclient.modules.Sprint;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public final class ModuleManager {
    public static final List<Module> ALL = List.of(new KillAura(), new Aimbot(), new Sprint(), new Fullbright());

    private ModuleManager() { }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("qclient.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            p.load(in);
        } catch (IOException ignored) {
            return; // first run: defaults
        }
        Minecraft mc = Minecraft.getInstance();
        for (Module m : ALL) {
            m.setEnabled(Boolean.parseBoolean(p.getProperty(m.name + ".enabled", "false")), mc);
            for (Setting s : m.settings) {
                String v = p.getProperty(m.name + "." + s.key);
                if (v != null) s.load(v);
            }
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ALL) {
            p.setProperty(m.name + ".enabled", Boolean.toString(m.isEnabled()));
            for (Setting s : m.settings) p.setProperty(m.name + "." + s.key, s.save());
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "QClient settings");
        } catch (IOException ignored) {
        }
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        for (Module m : ALL) {
            if (m.isEnabled()) m.tick(mc);
        }
    }
}
