package com.qclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** The in-game menu (Right Shift). Modules can only be switched here. */
public class ClickGuiScreen extends Screen {
    private static final int COL_W = 132, GAP = 10, ROW = 24, TOP = 44;

    public ClickGuiScreen() {
        super(Component.literal("QClient"));
    }

    private int startX() {
        int n = ModuleManager.ALL.size();
        return (this.width - (n * COL_W + (n - 1) * GAP)) / 2;
    }

    private static int rows(Module m) { return 1 + m.settings.size(); }

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance();
        int x = startX();
        for (Module m : ModuleManager.ALL) {
            int y = TOP;
            Button headBtn = Button.builder(headText(m), b -> {
                m.toggle(mc);
                b.setMessage(headText(m));
                ModuleManager.save();
            }).bounds(x, y, COL_W, 20).build();
            this.addRenderableWidget(headBtn);
            y += ROW;
            for (Setting s : m.settings) {
                if (s instanceof Setting.Num) {
                    Button mid = Button.builder(Component.literal(s.display()), b -> { })
                            .bounds(x + 22, y, COL_W - 44, 20).build();
                    mid.active = false;
                    this.addRenderableWidget(Button.builder(Component.literal("-"), b -> {
                        s.previous();
                        mid.setMessage(Component.literal(s.display()));
                        ModuleManager.save();
                    }).bounds(x, y, 20, 20).build());
                    this.addRenderableWidget(mid);
                    this.addRenderableWidget(Button.builder(Component.literal("+"), b -> {
                        s.next();
                        mid.setMessage(Component.literal(s.display()));
                        ModuleManager.save();
                    }).bounds(x + COL_W - 20, y, 20, 20).build());
                } else {
                    this.addRenderableWidget(Button.builder(Component.literal(s.display()), b -> {
                        s.next();
                        b.setMessage(Component.literal(s.display()));
                        ModuleManager.save();
                    }).bounds(x, y, COL_W, 20).build());
                }
                y += ROW;
            }
            x += COL_W + GAP;
        }
    }

    private static Component headText(Module m) {
        return Component.literal(m.name + (m.isEnabled() ? ": ВКЛ" : ": ВЫКЛ"));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.renderBackground(g, mouseX, mouseY, delta);
        int x = startX();
        for (Module m : ModuleManager.ALL) {
            int h = rows(m) * ROW + 6;
            g.fill(x - 4, TOP - 6, x + COL_W + 4, TOP - 6 + h + 6, 0xC0150A24);
            g.fill(x - 4, TOP - 6, x + COL_W + 4, TOP - 5, m.isEnabled() ? 0xFFE040B0 : 0xFF5A3A78);
            x += COL_W + GAP;
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, "QClient  ·  Right Shift или Esc — закрыть", this.width / 2, 16, 0xFFFFC0F0);
        int bottom = TOP;
        for (Module m : ModuleManager.ALL) {
            bottom = Math.max(bottom, TOP + rows(m) * ROW);
        }
        // module descriptions in a readable list under the panels
        int line = bottom + 10;
        for (Module m : ModuleManager.ALL) {
            g.drawCenteredString(this.font, m.name + " — " + m.description, this.width / 2, line, 0xFFD8C8F0);
            line += 12;
        }
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        ModuleManager.save();
    }
}
