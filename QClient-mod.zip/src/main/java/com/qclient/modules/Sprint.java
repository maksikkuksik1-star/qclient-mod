package com.qclient.modules;

import com.qclient.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Keeps sprinting while the forward key is held. */
public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "бежит сам, пока зажата клавиша вперёд");
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) return;
        if (mc.options.keyUp.isDown() && !p.isSprinting() && !p.horizontalCollision
                && !p.isUsingItem() && !p.isShiftKeyDown() && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
