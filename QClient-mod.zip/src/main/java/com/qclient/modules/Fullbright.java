package com.qclient.modules;

import com.qclient.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Lights up the world with a client-side night vision effect. */
public class Fullbright extends Module {
    private boolean applied;

    public Fullbright() {
        super("Fullbright", "максимальная яркость (ночное зрение только на экране)");
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 240) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
            applied = true;
        }
    }

    @Override
    protected void onDisable(Minecraft mc) {
        if (applied && mc.player != null) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
        }
        applied = false;
    }
}
