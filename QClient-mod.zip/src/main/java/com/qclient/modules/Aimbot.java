package com.qclient.modules;

import com.qclient.Module;
import com.qclient.Rotation;
import com.qclient.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/** Aim assist: pulls the crosshair toward the target closest to it. Never attacks by itself. */
public class Aimbot extends Module {
    private final Setting.Num range = add(new Setting.Num("range", "Дальность", 6.0, 3.0, 20.0, 1.0));
    private final Setting.Num fov = add(new Setting.Num("fov", "Угол обзора", 60, 10, 180, 10));
    private final Setting.Num smooth = add(new Setting.Num("smooth", "Плавность", 0.25, 0.05, 1.0, 0.05));
    private final Setting.Bool players = add(new Setting.Bool("players", "Игроки", true));
    private final Setting.Bool mobs = add(new Setting.Bool("mobs", "Мобы", false));
    private final Setting.Bool onlyAttack = add(new Setting.Bool("hold", "Только с ЛКМ", true));

    public Aimbot() {
        super("Aimbot", "подтягивает прицел к ближайшей к нему цели");
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || !p.isAlive()) return;
        if (onlyAttack.value && !mc.options.keyAttack.isDown()) return;

        double r = range.value;
        List<LivingEntity> found = mc.level.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(r),
                e -> e != p && e.isAlive() && !e.isSpectator()
                        && p.distanceTo(e) <= r
                        && ((players.value && e instanceof Player) || (mobs.value && e instanceof Enemy))
                        && p.hasLineOfSight(e));
        if (found.isEmpty()) return;

        float limit = fov.f() / 2.0f;
        LivingEntity best = null;
        float bestAngle = Float.MAX_VALUE;
        for (LivingEntity e : found) {
            float a = Rotation.angleTo(p, e.getBoundingBox().getCenter());
            if (a <= limit && a < bestAngle) {
                bestAngle = a;
                best = e;
            }
        }
        if (best == null) return;
        Vec3 point = best.getEyePosition();
        // gentle pull: a fraction of the remaining angle each tick, capped at 10 degrees
        Rotation.turnToward(p, point, smooth.f() * 0.5f, 10.0f);
    }
}
