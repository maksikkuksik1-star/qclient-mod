package com.qclient.modules;

import com.qclient.Module;
import com.qclient.Rotation;
import com.qclient.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/** Turns smoothly toward the nearest target and hits it once the weapon is charged. */
public class KillAura extends Module {
    private final Setting.Num range = add(new Setting.Num("range", "Дальность", 4.2, 2.5, 6.0, 0.1));
    private final Setting.Num turn = add(new Setting.Num("turn", "Скорость", 12, 2, 40, 2));
    private final Setting.Bool players = add(new Setting.Bool("players", "Игроки", true));
    private final Setting.Bool mobs = add(new Setting.Bool("mobs", "Мобы", false));
    private final Setting.Bool walls = add(new Setting.Bool("walls", "Сквозь стены", false));

    public KillAura() {
        super("KillAura", "плавно наводится на ближайшую цель и бьёт по перезарядке");
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;

        double r = range.value;
        List<LivingEntity> found = mc.level.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(r),
                e -> e != p && e.isAlive() && !e.isSpectator() && e.isAttackable()
                        && p.distanceTo(e) <= r
                        && ((players.value && e instanceof Player) || (mobs.value && e instanceof Enemy))
                        && (walls.value || p.hasLineOfSight(e)));
        if (found.isEmpty()) return;
        LivingEntity target = found.stream().min(Comparator.comparingDouble(p::distanceTo)).get();

        Vec3 aim = target.getBoundingBox().getCenter();
        // ease out: big steps far from the target, small ones near it, never faster than the chosen speed
        boolean onTarget = Rotation.turnToward(p, aim, 0.4f, turn.f());
        if (onTarget && p.getAttackStrengthScale(0.5f) >= 0.95f) {
            mc.gameMode.attack(p, target);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }
}
