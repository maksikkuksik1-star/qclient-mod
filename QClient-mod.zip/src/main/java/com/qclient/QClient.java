package com.qclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class QClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.load();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("qclient", "main"));
        KeyMapping menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.qclient.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.consumeClick()) {
                if (mc.screen == null && mc.player != null) {
                    mc.setScreen(new ClickGuiScreen());
                }
            }
            ModuleManager.tick(mc);
        });
    }
}
