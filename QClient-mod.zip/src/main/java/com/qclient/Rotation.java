package com.qclient;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Helpers for turning the player's view smoothly. */
public final class Rotation {
    private Rotation() { }

    public static float yawTo(Vec3 from, Vec3 to) {
        return (float) (Mth.atan2(to.z - from.z, to.x - from.x) * 180.0 / Math.PI) - 90.0f;
    }

    public static float pitchTo(Vec3 from, Vec3 to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return (float) -(Mth.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
    }

    /** Angular distance (degrees) between the current view and the point. */
    public static float angleTo(LocalPlayer p, Vec3 point) {
        Vec3 eye = p.getEyePosition();
        float dy = Mth.wrapDegrees(yawTo(eye, point) - p.getYRot());
        float dp = pitchTo(eye, point) - p.getXRot();
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    /**
     * Turns toward the point: each tick covers {@code ease} of the remaining angle,
     * but never more than {@code maxStep} degrees. Returns true when the view is within 8 degrees.
     */
    public static boolean turnToward(LocalPlayer p, Vec3 point, float ease, float maxStep) {
        Vec3 eye = p.getEyePosition();
        float dYaw = Mth.wrapDegrees(yawTo(eye, point) - p.getYRot());
        float dPitch = pitchTo(eye, point) - p.getXRot();
        p.setYRot(p.getYRot() + Mth.clamp(dYaw * ease, -maxStep, maxStep));
        p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(dPitch * ease, -maxStep, maxStep), -90.0f, 90.0f));
        return Math.abs(dYaw) < 8.0f && Math.abs(dPitch) < 8.0f;
    }
}
